# DecodeLabs Learning Hub — Project 1

**Responsive Frontend Interface** built for the DecodeLabs Full Stack Internship Program (Batch 2026).

## 🎯 Goal
Create a responsive frontend interface for a simple web application using HTML, CSS, and vanilla JavaScript — no frameworks.

## ✨ Features
- Fully responsive layout (mobile-first) — works on mobile, tablet, and desktop
- Semantic HTML5 structure (`header`, `nav`, `main`, `article`, `footer`, `aside`)
- CSS Grid for page layout + Flexbox for components
- Fluid typography using `clamp()`
- Interactive module filter (vanilla JavaScript)
- Mobile hamburger navigation menu
- Accessible design — keyboard focus states, skip link, ARIA labels

## 🛠️ Tech Stack
- HTML5
- CSS3 (Grid, Flexbox, Media Queries)
- Vanilla JavaScript

## 📱 Responsive Breakpoints
| Device  | Breakpoint |
|---------|-----------|
| Mobile  | Default (single column) |
| Tablet  | 768px+ |
| Desktop | 1024px+ |

## 📂 Project Structure
```
project1/
├── index.html
├── style.css
├── script.js
├── screenshot-hero.png
├── screenshot-modules.png
├── screenshot-footer.png
└── README.md
```

## 🖼️ Screenshots

### Hero Section
![Hero Section](screenshot-hero.png)

### Learning Modules Grid
![Learning Modules](screenshot-modules.png)

### Filter in Action + Footer
![Filter and Footer](screenshot-footer.png)

## 👩‍💻 Author
**Sakshi Kumari**  
DecodeLabs Full Stack Internship — Batch 2026

## 📧 Contact
DecodeLabs — decodelabs.tech@gmail.com | www.decodelabs.tech
